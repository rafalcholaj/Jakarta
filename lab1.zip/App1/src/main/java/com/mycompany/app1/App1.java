/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.app1;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author rafal
 */
public class App1 {

    private static EntityManagerFactory emf;

    public static void main(String[] args) {
        emf = Persistence.createEntityManagerFactory("MyPU_1");
        try (Scanner scanner = new Scanner(System.in)) {
            boolean run = true;
            while (run) {
                System.out.println("Choose an option: \n1. Add User \n2. Delete User \n3. Display Users \n4. Exit");
                int option = scanner.nextInt();
                scanner.nextLine(); // consume newline left-over
                switch (option) {
                    case 1:
                        addUser(scanner);
                        break;
                    case 2:
                        deleteUser(scanner);
                        break;
                    case 3:
                        displayUsers();
                        break;
                    case 4:
                        run = false;
                        break;
                    default:
                        System.out.println("Invalid option. Please choose again.");
                }
            }
        } finally {
            emf.close();
        }
    }

    private static void addUser(Scanner scanner) {
        System.out.println("Enter name:");
        String name = scanner.nextLine();
        System.out.println("Enter password:");
        String password = scanner.nextLine();

        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        Person person = new Person();
        person.setName(name);
        person.setPassword(password);
        em.persist(person);
        em.getTransaction().commit();
        em.close();
        System.out.println("User added successfully!");
    }

    private static void deleteUser(Scanner scanner) {
        System.out.println("Enter name of the user to delete:");
        String name = scanner.nextLine();

        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        Person person = em.find(Person.class, name);
        if (person != null) {
            em.remove(person);
            em.getTransaction().commit();
            System.out.println("User deleted successfully!");
        } else {
            System.out.println("User not found!");
        }
        em.close();
    }

    private static void displayUsers() {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        // Assuming Person entity correctly maps to a database table
        List<Person> people = em.createQuery("SELECT p FROM Person p", Person.class).getResultList();
        em.getTransaction().commit();
        for (Person person : people) {
            System.out.println("Name: " + person.getName() + ", Password: " + person.getPassword());
        }
        em.close();
    }
}
