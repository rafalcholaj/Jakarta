/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.app2;


import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;
import java.util.List;

/**
 *
 * @author rafal
 */
public class App2 {

    public static void main(String[] args) {
        EntityManagerFactory emfDB1 = Persistence.createEntityManagerFactory("MyPu(DB1)");
        EntityManagerFactory emfDB2 = Persistence.createEntityManagerFactory("MyPU(Msg)");
        transferUsers(emfDB1, emfDB2);
        emfDB1.close();
        emfDB2.close();
        
    }

    public static void transferUsers(EntityManagerFactory emfDB1, EntityManagerFactory emfDB2) {
        EntityManager emDB1 = emfDB1.createEntityManager();
        EntityManager emDB2 = emfDB2.createEntityManager();

        try {
            // Extract users from DB1
            emDB1.getTransaction().begin();
            TypedQuery<Person> query = 
                emDB1.createQuery("SELECT p FROM Person p", Person.class);
            List<Person> usersDB1 = query.getResultList();
            emDB1.getTransaction().commit();

            // Transfer users to DB2
            emDB2.getTransaction().begin();
            for (Person userDB1 : usersDB1) {
                Person userDB2 = new Person(); // Create a new Person instance for App2
                userDB2.setName(userDB1.getName());
                userDB2.setPassword(userDB1.getPassword());
                emDB2.persist(userDB2);
            }
            emDB2.getTransaction().commit();
            
            System.out.println("Users transferred successfully!");
        } catch (Exception e) {
            e.printStackTrace();
            if (emDB1.getTransaction().isActive()) {
                emDB1.getTransaction().rollback();
            }
            if (emDB2.getTransaction().isActive()) {
                emDB2.getTransaction().rollback();
            }
        } finally {
            emDB1.close();
            emDB2.close();
        }
    }
}
